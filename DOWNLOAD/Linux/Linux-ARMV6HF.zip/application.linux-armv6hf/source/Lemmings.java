import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Lemmings extends PApplet {

Pen pen;
Camera camera;
int BG_COL = color(30);
int WALL_COL = color(255);
int INVALID_COL = color(204,51,63);
int[] CAR_COLS = {color(255,0,255), color(0,255,0), color(0,0,255), color(255,0,255), color(255,255,0), color(0,255,255)};
boolean LOAD = false;
Generation squad;
Track track;
Menu menu;

public void setup() {
  
  frameRate(30);
  
  background(BG_COL);
  ellipseMode(RADIUS);
  pen = new Pen(2);
  camera = new Camera();
  track = new Track(50.0f);
  menu = new Menu();
}


public void draw() {
  background(BG_COL);
  track.display();
  if (squad != null) {
    squad.step();
    if (squad.finished()) {
      squad = new Generation(squad, 0.15f, 0.4f, 0.2f, track);
    }
  }
  else if (!track.building) {
    squad = new Generation(75, 10, new int[] {6}, track, color(0xffFF0066));
  }
  menu.display();
}


public void mousePressed() {
  track.create(new float[] {mouseX, mouseY});
  pen.set_prev();
}

public void keyPressed() {
  if (keyCode == BACKSPACE || keyCode == RETURN) {track.delete();}
  if (key == 'h' || key == 'H') {menu.change_page();}
  if (key == 'r' || key == 'R') {
    menu.page = 1;
    track = new Track(50.0f);
    squad = null;
  }
}
class Car {
  Track track;
  float x, y, speed, direction;
  float prev_x, prev_y, prev_direction;
  float max_speed, max_acceleration, max_steering;
  float view_angle, view_depth;
  int birth_time, checkpoint_time, checkpoint_limit;
  Ray[] rays;
  float size;
  int checkpoint = 0;
  Boolean dead = false;
  Boolean completed = false;
  Boolean best = false;
  int colour;

  Car(Car prev, Track t) {
    track = t;
    x = track.points.get(0)[0];
    y = track.points.get(0)[1];
    direction = atan2(track.points.get(1)[1] - y, track.points.get(1)[0] - x);
    prev_x = x;
    prev_y = y;
    prev_direction = direction;
    max_speed = prev.max_speed;
    max_acceleration = prev.max_acceleration;
    max_steering = prev.max_steering;
    view_angle = prev.view_angle;
    view_depth = prev.view_depth;
    birth_time = frameCount;
    checkpoint_time = frameCount;
    checkpoint_limit = floor(frameRate * 7);
    size = prev.size;
    generate_rays(prev.rays.length);
    colour = prev.colour;
  }

  Car(float spd, float ang, float dep, int num, Track t, int col) {
    track = t;
    x = track.points.get(0)[0];
    y = track.points.get(0)[1];
    direction = atan2(track.points.get(1)[1] - y, track.points.get(1)[0] - x);
    prev_x = x;
    prev_y = y;
    prev_direction = direction;
    max_speed = spd;
    max_acceleration = 0.3f;
    max_steering = 0.1f;
    view_angle = ang;
    view_depth = dep;
    birth_time = frameCount;
    checkpoint_time = frameCount;
    checkpoint_limit = floor(frameRate * 7);
    size = 5;
    generate_rays(num);
    colour = col;
  }

  public void display() {
    noStroke();
    fill(colour);
    if (best) {
      fill(0,0,255);
    }
    ellipse(x, y, size, size);
    //for (Ray ray : rays) {
      //ray.display();
    //}
  }
  
  public void display(int col) {
    fill(col);
    ellipse(x, y, size, size);
  }
  
  public void drive(float acceleration, float steering) {
    prev_x = x;
    prev_y = y;
    prev_direction = direction;
    speed += max_acceleration * acceleration;
    speed = max(min(speed, max_speed), -max_speed);
    direction += max_steering * steering;
    direction %= 2*PI;
    x += speed*cos(direction);
    y += speed*sin(direction);
    if (check_crashed()) {dead = true;}
    if (check_time()) {dead = true;}
    if (check_completed()) {
      dead = true;
      completed = true;
    }
    display();
  }

  public void generate_rays(int n) {
    rays = new Ray[n];
    float min_angle = - view_angle/2.0f;
    float interval = view_angle/PApplet.parseFloat(rays.length-1);
    for (int i=0; i<rays.length; i++) {
      float angle = min_angle + i*interval;
      rays[i] = new Ray(angle, view_depth, this);
    }
  }
  
  public float[] get_ray_distances() {
    float[] distances = new float[rays.length];
    for (int i = 0; i < rays.length; i++) {
      distances[i] = rays[i].distance();
    }
    return distances;
  }
  
  public Boolean check_crashed() {
    for (Segment segment : track.segments) {
      if(segment.intersects(this)) {return true;}
    }
    for (Corner corner : track.corners) {
      if(corner.intersects(this)) {return true;}
    }
    return false;
  }
  
  public Boolean check_time() {
    if (frameCount - checkpoint_time > checkpoint_limit) {
      return true;
    }
    return false;
  }

  public Boolean check_completed() {
    if (checkpoint == track.checkpoints.size()) {return true;}
    while (track.checkpoints.get(checkpoint).met(this)) {
      checkpoint += 1;
      checkpoint_time = frameCount;
      if (checkpoint == track.checkpoints.size()) {return true;}
    }
    return false;
  }
  
  public float distance() {
    float distance_travelled = 0;
    for (int i = 0; i < checkpoint; i++) {
      distance_travelled += track.segments.get(i).distance();
    }
    if (!completed) {
      distance_travelled += track.segments.get(checkpoint).distance(new float[] {x, y});
    }
    return distance_travelled;
  }
  
  public float speed() {
    float lap_time = (frameCount - birth_time);
    return distance() / lap_time;
  }
}



class Ray {
  float angle, distance;
  Car master;
  
  Ray(float a, float d, Car car) {
    angle = a;
    distance = d;
    master = car;
  }

  public void display() {
    stroke(master.colour);
    strokeWeight(master.size/2);
    float[] pos = intersect();
    point(pos[0], pos[1]);
  }

  public float[] position() {
    float x = master.x + master.view_depth*cos(master.direction+angle);
    float y = master.y + master.view_depth*sin(master.direction+angle);
    return new float[] {x, y};
  }

  public float[] intersect() {
    float[] min_intersect = position();
    float min_distance = pow(master.view_depth, 2);
    Boolean within_behind = true;
    Boolean within_ahead = true;
    Boolean ahead_range_segment = true;
    Boolean ahead_range_corner = true;
    Boolean behind_range_segment = true;
    Boolean behind_range_corner = true;
    int count = 0;
    while (within_behind || within_ahead) {
      int ahead = master.checkpoint + count;
      int behind = master.checkpoint - count;
      
      if (ahead < master.track.segments.size()) {
        Segment segment = master.track.segments.get(ahead);
        float[] intersect = segment.get_intersect(this);
        if (intersect != null) {
          float distance = pow(master.x-intersect[0], 2) + pow(master.y-intersect[1], 2);
          if (distance < min_distance) {
            min_intersect = intersect;
            min_distance = distance;
          }
        }
        if (!segment.within_range(master)) {ahead_range_segment = false;}
      }
      
      if (ahead < master.track.corners.size()) {
        Corner corner = master.track.corners.get(ahead);
        float[] intersect = corner.get_intersect(this);
        if (intersect != null) {
          float distance = pow(master.x-intersect[0], 2) + pow(master.y-intersect[1], 2);
          if (distance < min_distance) {
            min_intersect = intersect;
            min_distance = distance;
          }
        }
        if (!corner.within_range(master)) {ahead_range_corner = false;}
      }
      
      if (behind >= 0) {
        Segment segment = master.track.segments.get(behind);
        float[] intersect = segment.get_intersect(this);
        if (intersect != null) {
          float distance = pow(master.x-intersect[0], 2) + pow(master.y-intersect[1], 2);
          if (distance < min_distance) {
            min_intersect = intersect;
            min_distance = distance;
          }
        }
        if (!segment.within_range(master)) {behind_range_segment = false;}

        Corner corner = master.track.corners.get(behind);
        intersect = corner.get_intersect(this);
        if (intersect != null) {
          float distance = pow(master.x-intersect[0], 2) + pow(master.y-intersect[1], 2);
          if (distance < min_distance) {
            min_intersect = intersect;
            min_distance = distance;
          }
        }
        if (!corner.within_range(master)) {behind_range_corner = false;}
      }

      if (ahead >= master.track.segments.size() && ahead >= master.track.corners.size()) {within_ahead = false;}
      if (!ahead_range_segment && !ahead_range_corner) {within_ahead = false;}
      if (behind < 0) {within_behind = false;}
      if (!behind_range_segment && !behind_range_corner) {within_behind = false;}
      count++;
    }
    return min_intersect;
  }
  
  public float distance() {
    float[] pos = intersect();
    return sqrt(pow(master.x-pos[0], 2) + pow(master.y-pos[1], 2));
  }
}
class Menu {
  PFont font;
  int page;
  
  Menu() {
    font = createFont("Avenir Next", 16);
    page = 1;
  }
  
  public void display() {
    if (page > 0) {
      rectMode(CENTER);
      fill(255);
      noStroke();
      rect(width*0.5f, height*0.5f, width*0.6f, 155, 7);                          
      textAlign(CENTER, CENTER);
      fill(255);
      textAlign(CENTER, CENTER);
      fill(35);
    }
    
    if (page == 1) {
      textFont(font, 40);
      text("HELP", width*0.5f, height*0.5f - 60);
      textFont(font, 20);
      text("THIS IS AN AI RACING EXPERIMENT", width*0.5f, height*0.5f - 23);
      text("EACH CAR LEARNS HOW TO RACE THE TRACK", width*0.5f, height*0.5f + 1);
      text("THEY DO THIS VIA EVOLUTIONARY NEURAL NETWORKS", width*0.5f, height*0.5f + 25);
      text("PRESS [H] TO TOGGLE HELP", width*0.5f, height*0.5f + 49);
    }
    
    else if (page == 2) {
      textFont(font, 40);
      text("HELP", width*0.5f, height*0.5f - 60);
      textFont(font, 20);
      text("USE THE MOUSE TO DRAW A TRACK", width*0.5f, height*0.5f - 23);
      text("CLICK (NOT DRAG) TO DRAW CORNERS OF TRACK", width*0.5f, height*0.5f + 1);
      text("TRACK MUST BE A LOOP TO START BOTS", width*0.5f, height*0.5f + 25);
      text("PRESS [R] TO RESET TRACK & LEARNING", width*0.5f, height*0.5f + 49);
    }
  }
  
  public void change_page() {
    page++;
    if (page > 2) {page = 0;}
  }
}
class Matrix {
  float[][] array;
  int rows, columns;

  Matrix(Matrix copy) {
    array = new float[copy.rows][copy.columns];
    rows = array.length;
    columns = array[0].length;
    for (int r = 0; r < rows; r++) {
      for (int c = 0; c < columns; c++) {
        array[r][c] = copy.array[r][c];
      }
    }
  }

  Matrix(float[][] a) {
    array = a;
    rows = array.length;
    columns = array[0].length;
  }

  Matrix(int r, int c) {
    rows = r;
    columns = c;
    array = new float[rows][columns];
  }

  public void set_value(int r, int c, float v) {
    array[r][c] = v;
  }

  public void set_row(int r, float[] items) {
    array[r] = items;
  }

  public void set_column(int c, float[] items) {
    for (int r = 0; r < rows; r++) {
      array[r][c] = items[r];
    }
  }
  
  public float value(int r, int c) {
    return array[r][c];
  }
  
  public float[] row(int r) {
    return array[r];
  }

  public float[] column(int c) {
    float[] col = new float[rows];
    for (int r = 0; r < rows; r++) {
      col[r] = array[r][c];
    }
    return col;
  }
    
  public Matrix duplicate() {
    return new Matrix(this);
  }
}



public Matrix matrix_product(Matrix a, Matrix b) {
  Matrix product = new Matrix(a.rows, b.columns);
  for (int r = 0; r < product.rows; r++) {
    for (int c = 0; c < product.columns; c++) {
      product.set_value(r, c, dot_product(a.row(r), b.column(c)));
    }
  }
  return product;
}



public float dot_product(float[] a, float[] b) {//DOT PRODUCT OF TWO VECTORS
  float sum = 0;
  for (int i = 0; i < a.length; i++) {
    sum += a[i] * b[i];
  }
  return sum;
}


public float tanh(float x) {//MAPS X BETWEEN -1 and 1
  if (x > 10) {return 1;}//AVOIDS INFINITY/NAN WITH EXP
  if (x < -10) {return -1;}
  return (exp(x) - exp(-x)) / (exp(x) + exp(-x));
}



public float sigmoid(float x) {//MAPS X BETWEEN 0 AND 1
  return exp(x) / (exp(x) + 1);
}



public float point_line_relative_distance(float[] a1, float[] b1, float[] b2) {
  float[] p = {b2[1]-b1[1], b1[0]-b2[0]};                                                              //DIRECTION OF PERPENDICULAR
  float[] intersect = line_line_intersect(a1, new float[] {a1[0]+p[0], a1[1]+p[1]}, b1, b2);
  if (intersect == null) {intersect = a1;}
  return (intersect[0] - b1[0]) / (b2[0] - b1[0]);
}



public float[] line_line_intersect(float[] a1, float[] a2, float[] b1, float[] b2) {//A LINE BETWEEN A1/A2 AND B SEGMENT BETWEEN B1/B2
  float determinant = (a2[0]-a1[0])*(b1[1]-b2[1]) - (b1[0]-b2[0])*(a2[1]-a1[1]);
  if (determinant != 0) {                                                  //LINES INTERSECT
    float a_scalar = ((b1[1]-b2[1])*(b1[0]-a1[0]) + (b2[0]-b1[0])*(b1[1]-a1[1])) / determinant;
    return new float[] {a1[0] + a_scalar*(a2[0]-a1[0]), a1[1] + a_scalar*(a2[1]-a1[1])};
  }
  return null;
}



public float[] seg_seg_intersect(float[] a1, float[] a2, float[] b1, float[] b2) {//A SEGMENT BETWEEN A1/A2 AND B SEGMENT BETWEEN B1/B2
  float determinant = (a2[0]-a1[0])*(b1[1]-b2[1]) - (b1[0]-b2[0])*(a2[1]-a1[1]);
  if (determinant != 0) {                                                  //LINES INTERSECT
    float a_scalar = ((b1[1]-b2[1])*(b1[0]-a1[0]) + (b2[0]-b1[0])*(b1[1]-a1[1])) / determinant;
    float b_scalar = ((a1[1]-a2[1])*(b1[0]-a1[0]) + (a2[0]-a1[0])*(b1[1]-a1[1])) / determinant;
    if (a_scalar >= 0 && a_scalar <= 1 && b_scalar >= 0 && b_scalar <= 1) {//LINES INTERSECT WITHIN SEGMENT
      return new float[] {a1[0] + a_scalar*(a2[0]-a1[0]), a1[1] + a_scalar*(a2[1]-a1[1])};
    }
  }
  return null;
}



public float[] seg_circ_intersect(float[] a1, float[] a2, float[] center, float radius) {//A SEGMENT BETWEEN A1/A2
  float a = pow(a2[0]-a1[0], 2) + pow(a2[1]-a1[1], 2);//QUADRATIC FORUMULA TO FIND SCALAR
  float b = 2*(a1[0]-center[0])*(a2[0]-a1[0]) + 2*(a1[1]-center[1])*(a2[1]-a1[1]);
  float c = pow(a1[0]-center[0], 2) + pow(a1[1]-center[1], 2) - pow(radius, 2);
  float discriminant = pow(b, 2) - 4*a*c;
  if (discriminant >= 0) {
    float scalar_one = (-b + sqrt(discriminant)) / (2*a);//QUADRATIC SO TWO SLNS
    float scalar_two = (-b - sqrt(discriminant)) / (2*a);
    float[] intersect_one = {a1[0] + scalar_one*(a2[0]-a1[0]), a1[1] + scalar_one*(a2[1]-a1[1])};
    float[] intersect_two = {a1[0] + scalar_two*(a2[0]-a1[0]), a1[1] + scalar_two*(a2[1]-a1[1])};
    Boolean valid_one = false;
    Boolean valid_two = false;
    if (scalar_one >= 0 && scalar_one <= 1) {valid_one = true;}
    if (scalar_two >= 0 && scalar_two <= 1) {valid_two = true;}
    if (valid_one && valid_two) {
      if (scalar_one < scalar_two) {return intersect_one;}
      else {return intersect_two;}
    }
    if (valid_one) {return intersect_one;}
    if (valid_two) {return intersect_two;}
  }
  return null;
}



public float[] seg_arc_intersect(float[] a1, float[] a2, float[] center, float radius, float start, float end) {//A SEGMENT BETWEEN A1/A2
  float a = pow(a2[0]-a1[0], 2) + pow(a2[1]-a1[1], 2);//QUADRATIC FORUMULA TO FIND SCALAR
  float b = 2*(a1[0]-center[0])*(a2[0]-a1[0]) + 2*(a1[1]-center[1])*(a2[1]-a1[1]);
  float c = pow(a1[0]-center[0], 2) + pow(a1[1]-center[1], 2) - pow(radius, 2);
  float discriminant = pow(b, 2) - 4*a*c;
  if (discriminant >= 0) {
    float scalar_one = (-b + sqrt(discriminant)) / (2*a);//QUADRATIC SO TWO SLNS
    float scalar_two = (-b - sqrt(discriminant)) / (2*a);
    float[] intersect_one = {a1[0] + scalar_one*(a2[0]-a1[0]), a1[1] + scalar_one*(a2[1]-a1[1])};
    float[] intersect_two = {a1[0] + scalar_two*(a2[0]-a1[0]), a1[1] + scalar_two*(a2[1]-a1[1])};
    float angle_one = normalise_angle(atan2(intersect_one[1]-center[1], intersect_one[0]-center[0]));
    float angle_two = normalise_angle(atan2(intersect_two[1]-center[1], intersect_two[0]-center[0]));
    while (angle_one < start) {angle_one += TWO_PI;}
    while (angle_two < start) {angle_two += TWO_PI;}
    while (angle_one > end) {angle_one -= TWO_PI;}
    while (angle_two > end) {angle_two -= TWO_PI;}
    Boolean valid_one = false;
    Boolean valid_two = false;
    if (scalar_one >= 0 && scalar_one <= 1 && start <= angle_one && end >= angle_one) {valid_one = true;}
    if (scalar_two >= 0 && scalar_two <= 1 && start <= angle_two && end >= angle_two) {valid_two = true;}
    if (valid_one && valid_two) {
      if (scalar_one < scalar_two) {return intersect_one;}
      else {return intersect_two;}
    }
    if (valid_one) {return intersect_one;}
    if (valid_two) {return intersect_two;}
  }
  return null;
}



public float[] circ_circ_intersects(float[] center_a, float radius_a, float[] center_b, float radius_b) {//A CIRCLE AND B CIRCLE
  float d = sqrt(pow(center_a[0]-center_b[0], 2) + pow(center_a[1]-center_b[1], 2));
  if (d < radius_a + radius_b && d > abs(radius_a - radius_b) && d > 0) {
    float a = (pow(radius_a,2) - pow(radius_b,2) + pow(d,2)) / (2*d);
    float h = sqrt(pow(radius_a,2) - pow(a,2));
    float mid_x = center_a[0] + a*(center_b[0]-center_a[0])/d;
    float mid_y = center_a[1] + a*(center_b[1]-center_a[1])/d;
    float[] intersect_one = {mid_x + h*(center_b[1]-center_a[1])/d, mid_y - h*(center_b[0]-center_a[0])/d};
    float[] intersect_two = {mid_x - h*(center_b[1]-center_a[1])/d, mid_y + h*(center_b[0]-center_a[0])/d};
    return new float[] {intersect_one[0], intersect_one[1], intersect_two[0], intersect_two[1]};
  }
  return null;
}


public float[] arc_circ_intersects(float[] center_a, float radius_a, float start_a, float end_a, float[] center_b, float radius_b) {
  float[] intersects = circ_circ_intersects(center_a, radius_a, center_b, radius_b);
  if (intersects != null) {
    float[] intersect_one = {intersects[0], intersects[1]};
    float[] intersect_two = {intersects[2], intersects[3]};
    float angle_one = normalise_angle(atan2(intersect_one[1]-center_a[1], intersect_one[0]-center_a[0]));
    float angle_two = normalise_angle(atan2(intersect_two[1]-center_a[1], intersect_two[0]-center_a[0]));
    while (angle_one < start_a) {angle_one += TWO_PI;}
    while (angle_two < start_a) {angle_two += TWO_PI;}
    while (angle_one > end_a) {angle_one -= TWO_PI;}
    while (angle_two > end_a) {angle_two -= TWO_PI;}
    Boolean valid_one = false;
    Boolean valid_two = false;
    if (start_a <= angle_one && end_a >= angle_one) {valid_one = true;}
    if (start_a <= angle_two && end_a >= angle_two) {valid_two = true;}
    if (valid_one && valid_two) {
      return new float[] {intersect_one[0], intersect_one[1], intersect_two[0], intersect_two[1]};
    }
    if (valid_one) {return intersect_one;}
    if (valid_two) {return intersect_two;}
  }
  return null;
}


public float[] arc_arc_intersects(float[] center_a, float radius_a, float start_a, float end_a, float[] center_b, float radius_b, float start_b, float end_b) {
  float[] intersects = circ_circ_intersects(center_a, radius_a, center_b, radius_b);
  if (intersects != null) {
    float[] intersect_one = {intersects[0], intersects[1]};
    float[] intersect_two = {intersects[2], intersects[3]};
    float angle_a_one = normalise_angle(atan2(intersect_one[1]-center_a[1], intersect_one[0]-center_a[0]));
    float angle_a_two = normalise_angle(atan2(intersect_two[1]-center_a[1], intersect_two[0]-center_a[0]));
    float angle_b_one = normalise_angle(atan2(intersect_one[1]-center_b[1], intersect_one[0]-center_b[0]));
    float angle_b_two = normalise_angle(atan2(intersect_two[1]-center_b[1], intersect_two[0]-center_b[0]));
    while (angle_a_one < start_a) {angle_a_one += TWO_PI;}
    while (angle_a_two < start_a) {angle_a_two += TWO_PI;}
    while (angle_b_one < start_b) {angle_b_one += TWO_PI;}
    while (angle_b_two < start_b) {angle_b_two += TWO_PI;}
    while (angle_a_one > end_a) {angle_a_one -= TWO_PI;}
    while (angle_a_two > end_a) {angle_a_two -= TWO_PI;}
    while (angle_b_one > end_b) {angle_b_one -= TWO_PI;}
    while (angle_b_two > end_b) {angle_b_two -= TWO_PI;}
    Boolean valid_one = false;
    Boolean valid_two = false;
    if (start_a <= angle_a_one && end_a >= angle_a_one && start_b <= angle_b_one && end_b >= angle_b_one) {valid_one = true;}
    if (start_a <= angle_a_two && end_a >= angle_a_two && start_b <= angle_b_two && end_b >= angle_b_two) {valid_two = true;}
    if (valid_one && valid_two) {
      return new float[] {intersect_one[0], intersect_one[1], intersect_two[0], intersect_two[1]};
    }
    if (valid_one) {return intersect_one;}
    if (valid_two) {return intersect_two;}
  }
  return null;
}



public float normalise_angle(float angle) {
  while (angle < 0) {angle += TWO_PI;}
  while (angle > TWO_PI) {angle -= TWO_PI;}
  return angle;
}
class Network {
  Matrix[] neurons;
  Matrix[] weights;
  Matrix[] biases;
  
  Network(String name) {
    String[] records = loadStrings(name + ".csv");
    String[] neuron_data = split(records[0], ",");
    neurons = new Matrix[neuron_data.length];
    for (int layer = 0; layer < neurons.length; layer++) {
      neurons[layer] = new Matrix(PApplet.parseInt(neuron_data[layer]), 1);
    }
    String[] biases_data = split(records[1], ",");
    int record_count = 2;
    biases = new Matrix[biases_data.length];
    for (int layer = 0; layer < biases.length; layer++) {
      biases[layer] = new Matrix(PApplet.parseInt(biases_data[layer]), 1);
      String[] record_data = split(records[record_count], ",");
      for (int row = 0; row < biases[layer].rows; row++) {
        biases[layer].set_value(row, 0, PApplet.parseFloat(record_data[row]));
      }
      record_count += 1;
    } 
    String[] weights_data = split(records[record_count], ",");
    record_count += 1;
    weights = new Matrix[weights_data.length/2];
    for (int layer = 0; layer < weights.length; layer++) {
      weights[layer] = new Matrix(PApplet.parseInt(weights_data[layer*2]), PApplet.parseInt(weights_data[layer*2+1]));
      for (int row = 0; row < weights[layer].rows; row++) {
        String[] record_data = split(records[record_count], ",");
        for (int column = 0; column < weights[layer].columns; column++) {
          weights[layer].set_value(row, column, PApplet.parseFloat(record_data[column]));
        }
        record_count += 1;
      }
    } 
  }
  
  Network(int[] dimensions){
    neurons = new Matrix[dimensions.length];
    for (int i = 0; i < neurons.length; i++) {
      neurons[i] = new Matrix(dimensions[i], 1);
    }
   
    weights = new Matrix[dimensions.length-1];
    for (int i = 0; i < weights.length; i++) {
      weights[i] = new Matrix(dimensions[i+1], dimensions[i]);
    }
    
    biases = new Matrix[dimensions.length-1];
    for (int i = 0; i < biases.length; i++) {
      biases[i] = new Matrix(dimensions[i+1], 1);
    }
  }

  Network(Network prev) {
    neurons = new Matrix[prev.neurons.length];
    weights = new Matrix[prev.weights.length];
    biases = new Matrix[prev.biases.length];
    for (int i = 0; i < neurons.length; i++) {
      neurons[i] = new Matrix(prev.neurons[i]);
    }
    for (int i = 0; i < weights.length; i++) {
      weights[i] = new Matrix(prev.weights[i]);
    }
    for (int i = 0; i < biases.length; i++) {
      biases[i] = new Matrix(prev.biases[i]);
    }
  }
  
  Network(Network prev, float mutate_percent, float weight_range, float bias_range) {
    neurons = new Matrix[prev.neurons.length];
    weights = new Matrix[prev.weights.length];
    biases = new Matrix[prev.biases.length];
    for (int i = 0; i < neurons.length; i++) {
      neurons[i] = new Matrix(prev.neurons[i]);
    }
    for (int i = 0; i < weights.length; i++) {
      weights[i] = new Matrix(prev.weights[i]);
    }
    for (int i = 0; i < biases.length; i++) {
      biases[i] = new Matrix(prev.biases[i]);
    }
    for (Matrix matrix : weights) {
      for (int r = 0; r < matrix.rows; r++) {
        for (int c = 0; c < matrix.columns; c++) {
          if (random(1) < mutate_percent){
            matrix.set_value(r, c, matrix.value(r, c) + randomGaussian() * weight_range);
          }
        }
      }
    }
    for (Matrix matrix : biases) {
      for (int r = 0; r < matrix.rows; r++) {
        if (random(1) < mutate_percent){
          matrix.set_value(r, 0, matrix.value(r, 0) + randomGaussian() * bias_range);
        }
      }
    }
  }
    
  Network(Network a, Network b) {
    neurons = new Matrix[a.neurons.length];
    weights = new Matrix[a.weights.length];
    biases = new Matrix[a.biases.length];
    for (int i = 0; i < neurons.length; i++) {
      neurons[i] = new Matrix(a.neurons[i]);
    }
    for (int i = 0; i < weights.length; i++) {
      weights[i] = new Matrix(a.weights[i]);
    }
    for (int i = 0; i < biases.length; i++) {
      biases[i] = new Matrix(a.biases[i]);
    }
    for (int layer = 0; layer < weights.length; layer++) {
      for (int r = 0; r < weights[layer].rows; r++) {
        for (int c = 0; c < weights[layer].columns; c++) {
          if (random(1) > 0.5f) {weights[layer].set_value(r, c, b.weights[layer].value(r, c));}
        }
      }
    }
    for (int layer = 0; layer < biases.length; layer++) {
      for (int r = 0; r < biases[layer].rows; r++) {
        if (random(1) > 0.5f) {biases[layer].set_value(r, 0, b.biases[layer].value(r, 0));}
      }
    }
  }

  public void set_weights(int layer, Matrix values) {
    weights[layer] = values;
  }
  
  public void random_weights(float range) {
    for (Matrix matrix : weights) {
      for (int r = 0; r < matrix.rows; r++) {
        for (int c = 0; c < matrix.columns; c++) {
          matrix.set_value(r, c, randomGaussian() * range);
        }
      }
    }
  }

  public void random_biases(float range) {
    for (Matrix matrix : biases) {
      for (int r = 0; r < matrix.rows; r++) {
        matrix.set_value(r, 0, randomGaussian() * range);
      }
    }
  }
  
  public Matrix output(float[] input) {
    for (int i = 0; i < input.length; i++) {
      neurons[0].set_value(i, 0, input[i]);
    }
    return output(neurons.length-1);
  }
   
  public Matrix output(int layer) {//RECURSE BACK THROUGH LAYERS
    if (layer == 0) {
      return neurons[0];
    }
    Matrix product = matrix_product(weights[layer-1], output(layer-1));//FIND WEIGHTS X NODES IN PREVIOUS LAYER
    Matrix biased = new Matrix(product.rows, 1);  //ADD BIASES
    for (int r = 0; r < biased.rows; r++) {
      biased.set_value(r, 0, product.value(r, 0) + biases[layer-1].value(r, 0));
    }
    Matrix activated = new Matrix(biased.rows, 1);//ACTIVATE BETWEEN -1 AND 1
    for (int r = 0; r < biased.rows; r++) {
      activated.set_value(r, 0, tanh(biased.value(r, 0)));
    }
    neurons[layer] = activated;
    return neurons[layer];
  }
  
  public void display() {
    noFill();
    strokeWeight(2);
    int[] dims = {400, 400};
    int[] pos = {0, 0};
    float neuron_size = 5;
    float layer_width = dims[0] / neurons.length;
    for (int layer = 0; layer < neurons.length; layer++) {
      float neuron_height = dims[1] / neurons[layer].rows;
      for (int neuron = 0; neuron < neurons[layer].rows; neuron++) {
        float value = neurons[layer].value(neuron, 0);
        stroke(255*max(-value, 0), 255*max(value, 0), 0);
        ellipse(pos[0] + layer_width*(layer+0.5f), pos[0] + neuron_height*(neuron+0.5f), neuron_size, neuron_size);
      }
    }
  }

  public void store(String file_name) {
    PrintWriter file = createWriter(file_name + ".csv");
    for (int layer = 0; layer < neurons.length; layer++) {
      if (layer > 0) {file.print(',');}
      file.print(neurons[layer].rows);
    }
    file.print('\n');
    for (int layer = 0; layer < biases.length; layer++) {
      if (layer > 0) {file.print(',');}
      file.print(biases[layer].rows);
    }
    for (Matrix matrix : biases) {
      file.print('\n');
      for (int row = 0; row < matrix.rows; row++) {
        if (row > 0) {file.print(',');}
        file.print(matrix.value(row, 0));
      }
    }
    file.print('\n');
    for (int layer = 0; layer < weights.length; layer++) {
      if (layer > 0) {file.print(',');}
      file.print(str(weights[layer].rows) + ',' + str(weights[layer].columns));
    }
    for (Matrix matrix : weights) {
      file.print('\n');
      for (int row = 0; row < matrix.rows; row++) {
        if (row > 0) {file.print('\n');}
        for (int column = 0; column < matrix.columns; column++) {
          if (column > 0) {file.print(',');}
          file.print(matrix.value(row, column));
        }
      }
    }
    file.flush();
    file.close();
  }
}



class Bot {
  Network brain;
  Car machine;
  float score = 0;
  float speed_weight = 50;
  float distance_weight = 0.001f;
  float completed_weight;

  Bot(int inputs, int[] hidden_dimensions, Track track, int col) {
    int[] dimensions = concat(concat(new int[] {inputs+3}, hidden_dimensions), new int[] {2});
    brain = new Network(dimensions);
    brain.random_weights(10);
    brain.random_biases(10);
    machine = new Car(4, TWO_PI, 150, inputs, track, col);
  }

  Bot(String name, Track track, int col) {
    brain = new Network(name);
    machine = new Car(4, TWO_PI, 150, brain.neurons[0].rows-3, track, col);
  }

  Bot(Bot prev, Track track) {
    brain = new Network(prev.brain);
    machine = new Car(prev.machine, track);
  }
  
  Bot(Bot prev, float mutate_percent, float weight_range, float bias_range, Track track) {
    brain = new Network(prev.brain, mutate_percent, weight_range, bias_range);
    machine = new Car(prev.machine, track);
  }
  
  Bot(Bot a, Bot b, Track track) {
    brain = new Network(a.brain, b.brain);
    machine = new Car(a.machine, track);
  }
  
  public void step() {
    float[] inputs = new float[machine.rays.length+3];
    float[] relative_checkpoint = {machine.track.checkpoints.get(machine.checkpoint).x - machine.x, machine.track.checkpoints.get(machine.checkpoint).y - machine.y};
    inputs[0] = machine.speed / machine.max_speed;
    inputs[0] = normalise_angle(machine.direction - atan2(relative_checkpoint[1], relative_checkpoint[0])) / PI - 1;
    inputs[2] = min(sqrt(pow(relative_checkpoint[0], 2) + pow(relative_checkpoint[1], 2)), machine.view_depth) / machine.view_depth;
    float[] distances = machine.get_ray_distances();
    for (int i = 0; i < distances.length; i++) {
      inputs[i+3] = 2 * distances[i] / machine.view_depth - 1;
    }
    
    Matrix outputs = brain.output(inputs);
    float acceleration = outputs.value(0,0);
    float steering = outputs.value(1,0);
    machine.drive(acceleration, steering);
  }
  
  public void generate_score() {
    completed_weight = machine.track.segments.size() * distance_weight;
    if (machine.completed) {
      score += completed_weight + machine.speed() * speed_weight;
    }
    else {
      score += machine.distance() * distance_weight;
    }
  }
  
  public void reset(Track track) {
    boolean best = machine.best;
    machine = new Car(machine, track);
    machine.best = best;
  }
}



class Generation {
  Bot[] bots;
  int alive;
  
  Generation(int n, int inputs, int[] hidden_dimensions, Track track, int col) {
    bots = new Bot[n];
    alive = n;
    for (int i = 0; i < bots.length; i++) {
      bots[i] = new Bot(inputs, hidden_dimensions, track, col);
    }
  }

  Generation(Generation old_generation, float perfect_percent, float range, Track track) {
    bots = new Bot[old_generation.bots.length];
    alive = bots.length;
    int perfect_amount = min(round(bots.length * perfect_percent), bots.length);
    Bot[] sorted = sort_bots(old_generation.bots);

    float total_score = 0;
    for (Bot bot : sorted) {total_score += bot.score;}
    
    for (int i = 0; i < perfect_amount; i++) {
      bots[i] = new Bot(sorted[i], track);
      bots[i].machine.best = true;
    }

    for (int i = perfect_amount; i < bots.length; i++) {
      Bot random_bot = random_bot(sorted, total_score);
      float relative_range = range * pow((i-perfect_amount) / PApplet.parseFloat(bots.length-perfect_amount), 2);
      bots[i] = new Bot(random_bot, 1, relative_range, relative_range, track);
    }
  }


  Generation(Generation old_generation, float perfect_percent, float best_percent, float mutate_percent, Track track) {
    bots = new Bot[old_generation.bots.length];
    alive = bots.length;
    int perfect_amount = min(round(bots.length * perfect_percent), bots.length);
    int best_amount = min(round(bots.length * best_percent), bots.length);
    int mutate_amount = min(round(bots.length * mutate_percent), bots.length-perfect_amount-best_amount);
    Bot[] sorted = sort_bots(old_generation.bots);

    float total_score = 0;
    for (Bot bot : sorted) {total_score += bot.score;}
    
    for (int i = 0; i < perfect_amount; i++) {
      bots[i] = new Bot(sorted[i], track);
      bots[i].machine.best = true;
    }

    for (int i = perfect_amount; i < perfect_amount+best_amount; i++) {
      int random_index = floor(random(perfect_amount));
      bots[i] = new Bot(sorted[random_index], 0.8f, 1, 1, track);
    }

    for (int i = perfect_amount+best_amount; i < perfect_amount+best_amount+mutate_amount; i++) {
      Bot random_bot = random_bot(sorted, total_score);
      bots[i] = new Bot(random_bot, 1, 4, 4, track);
    }

    for (int i = perfect_amount+best_amount+mutate_amount; i < bots.length; i++) {//RANDOM FOR REST
      Bot random_bot_a = random_bot(sorted, total_score);
      Bot random_bot_b = random_bot(sorted, total_score);
      bots[i] = new Bot(random_bot_a, random_bot_b, track);//BREED
      bots[i] = new Bot(bots[i], 1, 6, 6, track);//MUTATE
    }
  }
   
  public void step() {
    for (Bot bot : bots) {
      if (!bot.machine.dead) {
        bot.step();
        if (bot.machine.dead) {
          bot.generate_score();
          alive -= 1;
        }
      }
    }
  }
  
  public void reset(Track track) {
    alive = bots.length;
    for (Bot bot : bots) {
      bot.reset(track);
    }
  }
  
  public Boolean finished() {
    for (Bot bot : bots) {
      if (!bot.machine.dead) {return false;}
    }
    return true;
  }
  
  public Bot lead() {
    Bot best = bots[0];
    for (Bot bot : bots) {
      if (bot.machine.distance() > best.machine.distance() && !bot.machine.dead) {
        best = bot;
      }
    }
    return best;
  }
  
  public Bot random_bot(Bot[] bots, float total) {
    float threshold = random(total);
    int index = 0;
    while (threshold > 0) {
      threshold -= bots[index].score;
      index += 1;
    }
    return bots[max(index-1,0)];
  }
  
  public Bot[] sort_bots(Bot[] unsorted) {
    if (unsorted.length > 1) {
      int m = unsorted.length/2;
      Bot[] a = (Bot[]) subset(unsorted,0,m);
      Bot[] b = (Bot[]) subset(unsorted,m,unsorted.length-m);
      return merge_bots(sort_bots(a), sort_bots(b));
    }
    return unsorted;
  }
  
  public Bot[] merge_bots(Bot[] a, Bot[] b) {
    Bot[] c = new Bot[a.length+b.length];
    int pa = 0;
    int pb = 0;
    int pc = 0;
    while (pa < a.length && pb < b.length) {
      if (a[pa].score > b[pb].score) {
        c[pc] = a[pa];
        pa++;
      }
      else {
        c[pc] = b[pb];
        pb++;
      }
      pc++;
    }
    while(pa < a.length) {
      c[pc] = a[pa];
      pa++;
      pc++;
    }
    while(pb < b.length) {
      c[pc] = b[pb];
      pb++;
      pc++;
    }
    return c;
  }
}


class Multi_Generation {
  Generation[] generations;
  Track track;
  int generation_count = 1;
  int track_count = 1;
  int max_track;
  int alive;
  
  Multi_Generation() {
    generations = new Generation[1];
    track = new Track(60, 50, 0.7f, 200);
    max_track = 1;
    alive = generations.length;
    generations[0] = new Generation(1, 10, new int[] {6}, track, CAR_COLS[0]);
    generations[0].bots[0].brain = new Network("test");
  }
  
  Multi_Generation(int n, int population, int t) {
    generations = new Generation[n];
    track = new Track(60, 50, 0.7f, 200);
    max_track = t;
    alive = generations.length;
    for (int i = 0; i < generations.length; i++) {
      generations[i] = new Generation(population, 10, new int[] {6}, track, CAR_COLS[i % CAR_COLS.length]);
    }
  }
  
  Multi_Generation(Multi_Generation prev) {
    generations = new Generation[prev.generations.length];
    generation_count = prev.generation_count + 1;
    track = new Track(60, 50, 0.7f, 200);
    max_track = prev.max_track;
    alive = generations.length;
    for (int i = 0; i < generations.length; i++) {
      generations[i] = new Generation(prev.generations[i], 0.15f, 0.4f, 0.2f, track);
    }
  }
  
  public void step() {
    track.display();
    for (Generation generation : generations) {
      if (!generation.finished()) {
        generation.step();
        if (generation.finished()) {
          alive -= 1;
        }
      }
    }
    if (alive == 0) {
      generate_track();
    }
  }
  
  public void generate_track() {
    if (track_count < max_track && generation_count >= 50) {
      track = new Track(60, 50, 0.7f, 200);
      for (Generation generation : generations) {
        generation.reset(track);
      }
      camera.set_pos(generations[0].bots[0]);
      alive = generations.length;
    }
    track_count += 1;
  }
  
  public boolean finished() {
    if (alive == 0 && (generation_count < 25 || track_count >= max_track)) {
      return true;
    }
    return false;
  }
  
  public Bot lead() {
    Bot global_lead = generations[0].lead();
    for (Generation generation : generations) {
      Bot local_lead = generation.lead();
      if (local_lead.machine.distance() > global_lead.machine.distance()) {
        global_lead = local_lead;
      }
    }
    return global_lead;
  }
}
class Track {
  ArrayList<float[]> points;
  ArrayList<Segment> segments;  
  ArrayList<Corner> corners;  
  ArrayList<Checkpoint> checkpoints;  
  float size, wall_thickness;
  Segment display_segment_a, display_segment_b, display_segment_c;
  Corner display_corner_a, display_corner_b, start_cap, end_cap;
  Boolean building = true;
  Boolean restrict_width = true;

  Track(String name) {
    String[] records = loadStrings(name + ".csv");
    String[] data = split(records[0], ",");
    size = PApplet.parseFloat(data[0]);
    wall_thickness = PApplet.parseFloat(data[1]);
    points = new ArrayList<float[]>();
    segments = new ArrayList<Segment>();
    corners = new ArrayList<Corner>();
    checkpoints = new ArrayList<Checkpoint>();
    for (int i = 1; i < records.length; i++) {
      data = split(records[i], ",");
      float[] pos = {PApplet.parseFloat(data[0]), PApplet.parseFloat(data[1])};
      create(pos);
    }
    data = split(records[1], ",");
    float[] pos = {PApplet.parseFloat(data[0]), PApplet.parseFloat(data[1])};
    create(pos);
  }

  Track(float s) {
    size = s;
    wall_thickness = 2;
    points = new ArrayList<float[]>();
    segments = new ArrayList<Segment>();
    corners = new ArrayList<Corner>();
    checkpoints = new ArrayList<Checkpoint>();
  }

  Track(float s, int n, float a, float r) {
    size = s;
    wall_thickness = 2;
    points = new ArrayList<float[]>();
    segments = new ArrayList<Segment>();
    corners = new ArrayList<Corner>();
    checkpoints = new ArrayList<Checkpoint>();
    restrict_width = false;
    float root = 0;
    float max = 0;
    while (points.size() <= n) {
      if (points.size() > max) {
        root = max;
      }
      Boolean generated = generate(a, r);
      if (!generated) {
        root = max(root-1, 0);
        while (points.size() > root) {
          delete();
        }
      }
    }
    corners.add(new Corner(segments.get(n-1), false));
    building = false;
  }

  public void create(float[] pos) {
    generate_display_ojects(pos);
    if (valid_point(pos) && building) {
      if (start_selected(pos)) {
        segments.add(new Segment(points.get(points.size()-1), points.get(0), size, wall_thickness, segments.get(segments.size()-1), segments.get(0)));
        corners.add(new Corner(segments.get(segments.size()-2), segments.get(segments.size()-1), points.get(points.size()-1)));
        corners.add(new Corner(segments.get(segments.size()-1), segments.get(0), points.get(0)));
        checkpoints.add(new Checkpoint(segments.get(segments.size()-2), segments.get(segments.size()-1), points.get(points.size()-1)));
        checkpoints.add(new Checkpoint(segments.get(segments.size()-1), segments.get(0), points.get(0)));
        building = false;
      }
      else {
        points.add(pos);
        if (points.size() > 1) {
          if (segments.size() > 0){
            segments.add(new Segment(points.get(points.size()-2), points.get(points.size()-1), size, wall_thickness, segments.get(segments.size()-1)));
            corners.add(new Corner(segments.get(segments.size()-2), segments.get(segments.size()-1), points.get(points.size()-2)));
            checkpoints.add(new Checkpoint(segments.get(segments.size()-2), segments.get(segments.size()-1), points.get(points.size()-2)));
          }
          else{
            segments.add(new Segment(points.get(points.size()-2), points.get(points.size()-1), size, wall_thickness, null));
          }
        }
      }
    }
  }

  public Boolean generate(float max_angle, float max_range) {
    float[] pos;
    float[] prev;
    float prev_angle;
    
    if (points.size() > 1) {
      prev = points.get(points.size()-1);
      float[] prev_prev = points.get(points.size()-2);
      prev_angle = atan2(prev[1] - prev_prev[1], prev[0] - prev_prev[0]);
    }
    else if (points.size() > 0) {
      prev = points.get(points.size()-1);
      prev_angle = 0;
    }
    else {
      prev = new float[] {width*0.25f + random(width*0.5f), height*0.25f + random(height*0.5f)};
      prev_angle = 0;
    }
    float angle = prev_angle + random(-max_angle, max_angle);
    float range = random(-max_range, max_range);
    pos = new float[] {prev[0] + cos(angle)*range, prev[1] + sin(angle)*range};
    generate_display_ojects(pos);
    float count = 0;
    while ((!valid_point(pos) || start_selected(pos)) && count < 10) {
      angle = prev_angle + random(-max_angle, max_angle);
      range = random(-max_range, max_range);
      pos = new float[] {prev[0] + cos(angle)*range, prev[1] + sin(angle)*range};
      generate_display_ojects(pos);
      count += 1;
    }
    if (valid_point(pos)) {
      create(pos);
      if (points.size() == 2) {corners.add(new Corner(segments.get(0), true));}
      return true;
    }
    return false;
  }

  public void delete() {
    if (building) {
      if (points.size() > 0) {points.remove(points.size()-1);}
      if (segments.size() > 0) {segments.remove(segments.size()-1);}
      if (corners.size() > 0) {corners.remove(corners.size()-1);}
      if (checkpoints.size() > 0) {checkpoints.remove(checkpoints.size()-1);}
    }
  }

  public void store(String file_name) {
    if (!building) {
      PrintWriter file = createWriter(file_name + ".csv");
      file.print(str(size) + "," + str(wall_thickness));
      for (float[] point : points) {
        file.print("\n" + str(point[0]) + "," + str(point[1]));
      }
      file.flush();
      file.close();
    }
  }

  public void display() {
    float[] display_point = {mouseX, mouseY};
    if (!building) {
      for (Segment segment : segments) {
        segment.display();
      }
      for (Corner corner : corners) {
        corner.display();
      }
    }
    
    else {
      for (int i = 0; i < segments.size()-1; i++) {
        if (!(i == 0 && start_selected(display_point))) {
          segments.get(i).display();
        }
      }
      for (Corner corner : corners) {
        corner.display();
      }
      generate_display_ojects(display_point);
      Boolean valid_point = valid_point(display_point);
      Boolean display_caps = true;
      
      if (points.size() > 1) {
        if(point_moved(display_point)) {
          if (start_selected(display_point)) {
            display_segment_c.display();
            display_corner_b.display();
            display_caps = false;
          }
          if (valid_point) {display_segment_a.display();}
          else {display_segment_a.display(INVALID_COL);}
          display_corner_a.display();
        }
        display_segment_b.display();
      }
      else if (points.size() == 1) {
        if (point_moved(display_point)) {
          if (valid_point) {display_segment_a.display();}
          else {display_segment_a.display(INVALID_COL);}
        }
      }
      if (display_caps) {
        start_cap.display();
        if (points.size() > 0) {
          if (!point_moved(display_point)) {
            end_cap.display();
          }
          else {
            if (valid_point) {end_cap.display();}
            else {end_cap.display(INVALID_COL);}
          }
        }
        else {
          if (valid_point) {end_cap.display();}
          else {end_cap.display(INVALID_COL);}
        }
      }
    }
  }
  
  public void generate_display_ojects(float[] pos) {
    if (points.size() == 0) {
      start_cap = new Corner(pos, size*0.5f, wall_thickness);
      end_cap = new Corner(pos, size*0.5f, wall_thickness);
    }
    else if (points.size() == 1) {
      if (point_moved(pos)) {
        display_segment_a = new Segment(points.get(points.size()-1), pos, size, wall_thickness, null);
        start_cap = new Corner(display_segment_a, true);
        end_cap = new Corner(display_segment_a, false);
      }
      else {
        start_cap = new Corner(pos, size*0.5f, wall_thickness);
        end_cap = new Corner(pos, size*0.5f, wall_thickness);
      }
    }
    else {
      start_cap = new Corner(segments.get(0), true);
      if (segments.size() > 1) {
        Segment duplicate_segment_b = new Segment(points.get(points.size()-3), points.get(points.size()-2), size, wall_thickness, null);
        display_segment_b = new Segment(points.get(points.size()-2), points.get(points.size()-1), size, wall_thickness, duplicate_segment_b);
        if (start_selected(pos)) {
          Segment duplicate_segment_c = new Segment(points.get(1), points.get(2), size, wall_thickness, null);
          display_segment_c = new Segment(points.get(0), points.get(1), size, wall_thickness, null, duplicate_segment_c);
        }
      }
      else {
        display_segment_b = new Segment(points.get(points.size()-2), points.get(points.size()-1), size, wall_thickness, null);
        if (start_selected(pos)) {
          display_segment_c = new Segment(points.get(0), points.get(1), size, wall_thickness, null);
        }
      }
      if (point_moved(pos)) {
        if (start_selected(pos)) {
          display_segment_a = new Segment(points.get(points.size()-1), points.get(0), size, wall_thickness, display_segment_b, display_segment_c);
          display_corner_b = new Corner(display_segment_a, display_segment_c, points.get(0));
        }
        else {
          display_segment_a = new Segment(points.get(points.size()-1), pos, size, wall_thickness, display_segment_b);
        }
        display_corner_a = new Corner(display_segment_b, display_segment_a, points.get(points.size()-1));
        end_cap = new Corner(display_segment_a, false);
      }
      else {
        end_cap = new Corner(segments.get(segments.size()-1), false);
      }
    }
  }
    
  public Boolean valid_point(float[] point) {
    if (start_selected(point)) {
      if (display_segment_a.invalid) {return false;}
      for (int i = 1; i < segments.size()-1; i++) {
        if (display_segment_a.intersects(segments.get(i))) {return false;}
      }
      for (Corner corner : corners) {
        if (display_segment_a.intersects(corner)) {return false;}
      }
      return true;
    }
    
    if (restrict_width) {
      if (point[0]-size*0.5f < 0 || point[0]+size*0.5f > width) {return false;}
      if (point[1]-size*0.5f < 0 || point[1]+size*0.5f > height) {return false;}
    }
    
    if (!point_moved(point)) {return false;}
    if (start_cap.intersects(end_cap)) {return false;}

    if (points.size() > 0) {
      if (display_segment_a.invalid) {return false;}
      if (display_segment_a.intersects(start_cap) && points.size() > 1) {return false;}
      for (int i = 0; i < segments.size()-1; i++) {
        if (display_segment_a.intersects(segments.get(i))) {return false;}
      }
      for (Corner corner : corners) {
        if (display_segment_a.intersects(corner)) {return false;}
      }
    }
    
    for (int i = 0; i < segments.size(); i++) {
      if (i != 0) {
        if (start_cap.intersects(segments.get(i))) {return false;}
      }
      if (i != segments.size()-1) {
        if (end_cap.intersects(segments.get(i))) {return false;}
      }
    }
    
    for (Corner corner : corners) {
      if (start_cap.intersects(corner)) {return false;}
      if (end_cap.intersects(corner)) {return false;}
    }
    return true;
  }
  
  public Boolean point_moved(float[] pos) {
    if (points.size() > 0) {
      if (points.get(points.size()-1)[0] == pos[0] && points.get(points.size()-1)[1] == pos[1]) {  
        return false;
      }
    }
    return true;
  }

  public Boolean start_selected(float[] pos) {
    if (points.size() > 1) {
      if (pow(points.get(0)[0]-pos[0], 2) + pow(points.get(0)[1]-pos[1], 2) < pow(size/2.0f, 2)) {
        return true;
      }
    }
    return false;
  }
}



class Segment {
  float[][][] walls; 
  float[][][] edges; 
  float x1, y1, x2, y2, diameter, thickness;
  Segment prev, next;
  boolean invalid = false;

  Segment(float[] a, float[] b, float d, float t, Segment p) {
    x1 = a[0];
    y1 = a[1];
    x2 = b[0];
    y2 = b[1];
    diameter = d;
    thickness = t;
    prev = p;
    next = null;
    if (prev != null) {prev.next = this;}
    generate_walls();
    generate_edges();
  }

  Segment(float[] a, float[] b, float d, float t, Segment p, Segment n) {
    x1 = a[0];
    y1 = a[1];
    x2 = b[0];
    y2 = b[1];
    diameter = d;
    thickness = t;
    prev = p;
    next = n;
    if (prev != null) {prev.next = this;}
    if (next != null) {next.prev = this;}
    generate_walls();
    generate_edges();
  }
  
  public void display() {
    stroke(WALL_COL);
    strokeWeight(thickness);
    line(walls[0][0][0], walls[0][0][1], walls[0][1][0], walls[0][1][1]);
    line(walls[1][0][0], walls[1][0][1], walls[1][1][0], walls[1][1][1]);
  }

  public void display(int col) {
    noFill();
    stroke(col);
    strokeWeight(thickness);
    line(walls[0][0][0], walls[0][0][1], walls[0][1][0], walls[0][1][1]);
    line(walls[1][0][0], walls[1][0][1], walls[1][1][0], walls[1][1][1]);
  }
  
  public void generate_walls() {
    float[] direction = {x2-x1, y2-y1};                                                                  //DIRECTION OF SEGMENT
    float scalar = diameter*0.5f / sqrt(pow(direction[0], 2) + pow(direction[1], 2));                     //NORMALISE AND THEN SCALE TO DIAMETER
    float[] shift = {direction[1]*scalar, -direction[0]*scalar};                                         //SHIFT EACH EDGE PERPENDICULAR TO SEGMENT
    float[][] positive = new float[][] {new float[] {x1+shift[0], y1+shift[1]}, new float[] {x2+shift[0], y2+shift[1]}};
    float[][] negative = new float[][] {new float[] {x1-shift[0], y1-shift[1]}, new float[] {x2-shift[0], y2-shift[1]}};
    walls = new float[][][] {positive, negative};
    
    if (prev != null) {//SHORTEN WALLS IF CURRENT/PREV INTERSECT
      float[] positive_intersect = seg_seg_intersect(walls[0][0], walls[0][1], prev.walls[0][0], prev.walls[0][1]);
      float[] negative_intersect = seg_seg_intersect(walls[1][0], walls[1][1], prev.walls[1][0], prev.walls[1][1]);
      if (positive_intersect != null) {
        walls[0][0] = positive_intersect;
        prev.walls[0][1] = positive_intersect;
      }
      else if (negative_intersect != null) {
        walls[1][0] = negative_intersect;
        prev.walls[1][1] = negative_intersect;
      }
      if (!(walls[0][0][0] == prev.walls[0][1][0] && walls[0][0][1] == prev.walls[0][1][1]) && !(walls[1][0][0] == prev.walls[1][1][0] && walls[1][0][1] == prev.walls[1][1][1])) {
        invalid = true;
      }
    }

    if (next != null) {//SHORTEN WALLS IF CURRENT/NEXT INTERSECT
      float[] positive_intersect = seg_seg_intersect(walls[0][0], walls[0][1], next.walls[0][0], next.walls[0][1]);
      float[] negative_intersect = seg_seg_intersect(walls[1][0], walls[1][1], next.walls[1][0], next.walls[1][1]);
      if (positive_intersect != null) {
        walls[0][1] = positive_intersect;
        next.walls[0][0] = positive_intersect;
      }
      else if (negative_intersect != null) {
        walls[1][1] = negative_intersect;
        next.walls[1][0] = negative_intersect;
      }
      if (!(walls[0][1][0] == next.walls[0][0][0] && walls[0][1][1] == next.walls[0][0][1]) && !(walls[1][1][0] == next.walls[1][0][0] && walls[1][1][1] == next.walls[1][0][1])) {
        invalid = true;
      }
    }
  }

  public void generate_edges() {
    float[] direction = {x2-x1, y2-y1};                                                                  //DIRECTION OF SEGMENT
    float scalar = (diameter*0.5f-thickness*0.5f) / sqrt(pow(direction[0], 2) + pow(direction[1], 2));     //NORMALISE AND THEN SCALE TO DIAMETER - THICKNESS
    float[] shift = {direction[1]*scalar, -direction[0]*scalar};                                         //SHIFT EACH EDGE PERPENDICULAR TO SEGMENT
    float[][] positive = new float[][] {new float[] {x1+shift[0], y1+shift[1]}, new float[] {x2+shift[0], y2+shift[1]}};
    float[][] negative = new float[][] {new float[] {x1-shift[0], y1-shift[1]}, new float[] {x2-shift[0], y2-shift[1]}};
    edges = new float[][][] {positive, negative};

    if (prev != null) {//SHORTEN EDGES IF CURRENT/PREV INTERSECT
      float[] positive_intersect = seg_seg_intersect(edges[0][0], edges[0][1], prev.edges[0][0], prev.edges[0][1]);
      float[] negative_intersect = seg_seg_intersect(edges[1][0], edges[1][1], prev.edges[1][0], prev.edges[1][1]);
      if (positive_intersect != null) {
        edges[0][0] = positive_intersect;
        prev.edges[0][1] = positive_intersect;
      }
      else if (negative_intersect != null) {
        edges[1][0] = negative_intersect;
        prev.edges[1][1] = negative_intersect;
      }
    }

    if (next != null) {//SHORTEN EDGES IF CURRENT/NEXT INTERSECT
      float[] positive_intersect = seg_seg_intersect(edges[0][0], edges[0][1], next.edges[0][0], next.edges[0][1]);
      float[] negative_intersect = seg_seg_intersect(edges[1][0], edges[1][1], next.edges[1][0], next.edges[1][1]);
      if (positive_intersect != null) {
        edges[0][1] = positive_intersect;
        next.edges[0][0] = positive_intersect;
      }
      else if (negative_intersect != null) {
        edges[1][1] = negative_intersect;
        next.edges[1][0] = negative_intersect;
      }
    }
  }

  public float distance() {
    return sqrt(pow(x1 - x2, 2) + pow(y1 - y2, 2));
  }

  public float distance(float[] pos) {
    float scalar = point_line_relative_distance(pos, new float[] {x1, y1}, new float[] {x2, y2});
    return scalar * distance();
  }
  
  public float[] get_intersect(Ray ray) {
    float[] intersect_a = seg_seg_intersect(ray.position(), new float[] {ray.master.x, ray.master.y}, walls[0][0], walls[0][1]);
    float[] intersect_b = seg_seg_intersect(ray.position(), new float[] {ray.master.x, ray.master.y}, walls[1][0], walls[1][1]);    
    if (intersect_a == null && intersect_b == null) {
      return null;
    }
    else if (intersect_a == null) {
      return intersect_b;
    }
    else if (intersect_b == null) {
      return intersect_a;
    }
    float distance_a = pow(intersect_a[0]-ray.master.x, 2)+pow(intersect_a[1]-ray.master.y, 2);
    float distance_b = pow(intersect_b[0]-ray.master.x, 2)+pow(intersect_b[1]-ray.master.y, 2);
    if (distance_a < distance_b) {
      return intersect_a;
    }
    return intersect_b;
  }
  
  public Boolean within_range(Car car) {
    float distance_a = pow(walls[0][0][0]-car.x, 2) + pow(walls[0][0][1]-car.y, 2);
    float distance_b = pow(walls[0][1][0]-car.x, 2) + pow(walls[0][1][1]-car.y, 2);
    float distance_c = pow(walls[1][0][0]-car.x, 2) + pow(walls[1][0][1]-car.y, 2);
    float distance_d = pow(walls[1][1][0]-car.x, 2) + pow(walls[1][1][1]-car.y, 2);
    float[] intersect_a = seg_circ_intersect(walls[0][0], walls[0][1], new float[] {car.x, car.y}, car.view_depth);
    float[] intersect_b = seg_circ_intersect(walls[1][0], walls[1][1], new float[] {car.x, car.y}, car.view_depth);
    float[] distances = {distance_a, distance_b, distance_c, distance_d};

    if (sqrt(min(distances)) > car.view_depth && intersect_a == null && intersect_b == null) {
      return false;
    }
    return true;
  }
  
  public Boolean intersects(Segment other) {
    float[] intersect_a = seg_seg_intersect(other.walls[0][0], other.walls[0][1], walls[0][0], walls[0][1]);
    float[] intersect_b = seg_seg_intersect(other.walls[0][0], other.walls[0][1], walls[1][0], walls[1][1]);
    float[] intersect_c = seg_seg_intersect(other.walls[1][0], other.walls[1][1], walls[0][0], walls[0][1]);
    float[] intersect_d = seg_seg_intersect(other.walls[1][0], other.walls[1][1], walls[1][0], walls[1][1]);
    if (intersect_a == null && intersect_b == null && intersect_c == null && intersect_d == null) {
      return false;
    }
    return true;
  }

  public Boolean intersects(Corner corner) {
    float[] intersect_a = seg_arc_intersect(walls[0][0], walls[0][1], corner.center, corner.wall_radius, corner.start, corner.end);
    float[] intersect_b = seg_arc_intersect(walls[1][0], walls[1][1], corner.center, corner.wall_radius, corner.start, corner.end);
    if (intersect_a == null && intersect_b == null) {
      return false;
    }
    return true;
  }

  public Boolean intersects(Car car) {
    float[] intersect_a = seg_circ_intersect(edges[0][0], edges[0][1], new float[] {car.x, car.y}, car.size);
    float[] intersect_b = seg_circ_intersect(edges[1][0], edges[1][1], new float[] {car.x, car.y}, car.size);
    if (intersect_a != null || intersect_b != null) {return true;}
    intersect_a = seg_seg_intersect(edges[0][0], edges[0][1], new float[] {car.prev_x, car.prev_y}, new float[] {car.x, car.y});
    intersect_b = seg_seg_intersect(edges[1][0], edges[1][1], new float[] {car.prev_x, car.prev_y}, new float[] {car.x, car.y});
    if (intersect_a != null || intersect_b != null) {return true;}
    return false;
  }
}



class Corner {
  float start, end, wall_radius, edge_radius, thickness;
  float[] center;

  Corner(float[] c, float r, float t) {
    center = c;
    thickness = t;
    wall_radius = r;
    edge_radius = wall_radius - thickness*0.5f;
    start = 0;
    end = TWO_PI;
  }

  Corner(Segment segment, Boolean at_beginning) {
    thickness = segment.thickness;
    wall_radius = segment.diameter*0.5f;
    edge_radius = wall_radius - thickness*0.5f;
    float x1, y1, x2, y2;
    if (at_beginning) {
      center = new float[] {(segment.walls[0][0][0]+segment.walls[1][0][0])*0.5f, (segment.walls[0][0][1]+segment.walls[1][0][1])*0.5f};
      x1 = segment.walls[1][0][0] - center[0];
      y1 = segment.walls[1][0][1] - center[1];
      x2 = segment.walls[0][0][0] - center[0];
      y2 = segment.walls[0][0][1] - center[1];
    }
    else {
      center = new float[] {(segment.walls[0][1][0]+segment.walls[1][1][0])*0.5f, (segment.walls[0][1][1]+segment.walls[1][1][1])*0.5f};
      x1 = segment.walls[0][1][0] - center[0];
      y1 = segment.walls[0][1][1] - center[1];
      x2 = segment.walls[1][1][0] - center[0];
      y2 = segment.walls[1][1][1] - center[1];
    }
    start = normalise_angle(atan2(y1, x1));
    end = normalise_angle(atan2(y2, x2));
    if (start > end) {end += TWO_PI;}
  }

  Corner(Segment a, Segment b, float[] c) {
    thickness = a.thickness;
    wall_radius = a.diameter*0.5f;
    edge_radius = wall_radius - thickness*0.5f;
    center = c;
    if (seg_seg_intersect(a.walls[0][0], a.walls[0][1], b.walls[0][0], b.walls[0][1]) != null) {      
      float x1 = b.walls[1][0][0] - center[0];
      float y1 = b.walls[1][0][1] - center[1];
      float x2 = a.walls[1][1][0] - center[0];
      float y2 = a.walls[1][1][1] - center[1];
      start = normalise_angle(atan2(y1, x1));
      end = normalise_angle(atan2(y2, x2));
    }
    else if (seg_seg_intersect(a.walls[1][0], a.walls[1][1], b.walls[1][0], b.walls[1][1]) != null) {
      float x1 = b.walls[0][0][0] - center[0];
      float y1 = b.walls[0][0][1] - center[1];
      float x2 = a.walls[0][1][0] - center[0];
      float y2 = a.walls[0][1][1] - center[1];
      end = normalise_angle(atan2(y1, x1));
      start = normalise_angle(atan2(y2, x2));
    }
    else {
      start = 0;
      end = 0;
    }
    if (start > end) {end += TWO_PI;}
  }
  
  public void display() {
    noFill();
    stroke(WALL_COL);
    strokeWeight(thickness);
    arc(center[0], center[1], wall_radius, wall_radius, start, end);
  }

  public void display(int col) {
    noFill();
    stroke(col);
    strokeWeight(thickness);
    arc(center[0], center[1], wall_radius, wall_radius, start, end);
  }
  
  public float[] get_intersect(Ray ray) {
    float[] intersect = seg_arc_intersect(ray.position(), new float[] {ray.master.x, ray.master.y}, center, edge_radius, start, end);
    return intersect;
  }
  
  public Boolean within_range(Car car) {
    if (sqrt(pow(center[0] - car.x, 2) + pow(center[1] - car.y, 2)) - wall_radius > car.view_depth) {
      return false;
    }
    return true;
  }
      
  public Boolean intersects(Segment segment) {
    float[] intersect_a = seg_arc_intersect(segment.walls[0][0], segment.walls[0][1], center, wall_radius, start, end);
    float[] intersect_b = seg_arc_intersect(segment.walls[1][0], segment.walls[1][1], center, wall_radius, start, end);
    if (intersect_a == null && intersect_b == null) {
      return false;
    }
    return true;
  }
  
  public Boolean intersects(Corner other) {
    float[] intersect_pair = arc_arc_intersects(center, wall_radius, start, end, other.center, other.wall_radius, other.start, other.end);
    if (intersect_pair == null) {
      return false;
    }
    return true;
  }
  
  public Boolean intersects(Car car) {
    float[] intersect = arc_circ_intersects(center, edge_radius, start, end, new float[] {car.x, car.y}, car.size);
    if (intersect != null) {return true;}
    intersect = seg_arc_intersect(new float[] {car.prev_x, car.prev_y}, new float[] {car.x, car.y}, center, edge_radius, start, end);
    if (intersect != null) {return true;}
    return false;
  }
}



class Checkpoint {
  float x, y, x1, y1, x2, y2;
  
  Checkpoint(Segment a, Segment b, float[] center) {
    if (a.walls[0][1][0] == b.walls[0][0][0] && a.walls[0][1][1] == b.walls[0][0][1]) {      
      x1 = a.walls[0][1][0];
      y1 = a.walls[0][1][1];
    }
    else {
      x1 = a.walls[1][1][0];
      y1 = a.walls[1][1][1];
    }
    float angle = atan2(y1-center[1], x1-center[0]);
    x2 = center[0] - a.diameter*0.5f*cos(angle);
    y2 = center[1] - a.diameter*0.5f*sin(angle);
    x = 0.5f * (x1 + x2);
    y = 0.5f * (y1 + y2);
  }

  public void display() {
    line(x1, y1, x2, y2);
  }
  
  public Boolean met(Car car) {
    float[] intersect = seg_circ_intersect(new float[] {x1, y1}, new float[] {x2, y2}, new float[] {car.x, car.y}, car.size);
    if (intersect != null) {return true;}
    intersect = seg_seg_intersect(new float[] {x1, y1}, new float[] {x2, y2}, new float[] {car.prev_x, car.prev_y}, new float[] {car.x, car.y});
    if (intersect != null) {return true;}
    return false;
  }
}
class Pen {
  float size;
  float[] prev;
  
  Pen(float s) {
    size = s;
    prev = new float[2];
  }
  
  public void set_prev() {
    prev[0] = mouseX;
    prev[1] = mouseY;
  }
}


class Camera {
  float x, y;

  Camera() {
    x = 0;
    y = 0;
  }
  
  public float[] pos(Bot lead) {
    x += 0.05f * (lead.machine.x - x);
    y += 0.05f * (lead.machine.y - y);
    return new float[] {x, y};
  }
  
  public void set_pos(Bot bot) {
    x = bot.machine.x;
    y = bot.machine.y;
  }
}
  public void settings() {  size(900,600);  pixelDensity(displayDensity()); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Lemmings" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
